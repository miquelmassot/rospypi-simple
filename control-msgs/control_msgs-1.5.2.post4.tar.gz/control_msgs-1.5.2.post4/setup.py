from setuptools import find_packages, setup
setup(name='control_msgs', version='1.5.2.post4', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])