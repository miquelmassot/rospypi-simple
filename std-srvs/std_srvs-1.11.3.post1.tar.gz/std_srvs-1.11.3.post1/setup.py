from setuptools import find_packages, setup
setup(name='std_srvs', version='1.11.3.post1', packages=find_packages(),
      install_requires=['genpy>=0.6.14,<2000'])